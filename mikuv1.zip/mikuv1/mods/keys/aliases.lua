--
-- Aliases for backward compatibility
--

minetest.register_alias("default:key", "keys:key")
minetest.register_alias("default:skeleton_key", "keys:skeleton_key")
