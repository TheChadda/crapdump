Minetest Game mod: xpanes
=========================
See license.txt for license information.

Authors of source code
----------------------
Originally by xyz (MIT)
BlockMen (MIT)
sofar (MIT)
Various Minetest developers and contributors (MIT)

Authors of media (textures)
---------------------------
xyz (CC BY-SA 3.0):
  All textures not mentioned below.

Gambit (CC BY-SA 3.0):
  xpanes_bar.png

paramat (CC BY-SA 3.0):
  xpanes_bar_top.png

Krock (CC0 1.0):
  xpanes_edge.png

TumeniNodes (CC BY-SA 3.0):
  xpanes_door_steel_bar.png
  xpanes_item_steel_bar.png
  xpanes_trapdoor_steel_bar.png
  xpanes_trapdoor_steel_bar_side.png
  xpanes_steel_bar_door_close.ogg
  xpanes_steel_bar_door_open.ogg
